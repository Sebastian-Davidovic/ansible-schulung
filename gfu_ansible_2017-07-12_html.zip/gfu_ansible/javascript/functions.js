function fold(d) {
    var $node = $('#' + d);

    $node.toggle(250, "linear", function () {

        //alert($node.prev().prev().clone().html());

        if (! $node.prev().prev().find('.multiplechoice').length) {
            return;
        }


        var $correct = $("<p/>")
            .addClass('reporting')
            .append("<b>Richtig!</b>");

	$correct.find('b')
            .css({'color': 'green',
                  'border' : '1px solid green',
                  'background': '#BFB',
                  'padding': '0.2em',
                });	    
        
        var $incorrect = $("<p/>")
            .addClass('reporting')
            .append("<b>Leider falsch.</b>");

	$incorrect.find('b')
            .css({'color': 'red',
                  'border' : '1px solid red',
                  'background': '#FBB',
                  'padding': '0.2em',
                });


        var $checkboxes = $node.prev().prev().find('input');
        
        var wanted = [];
        $checkboxes.each(function () {
            wanted.push( $(this).is('.correct')? 1 : 0 );
        });


        if ($node.is(':visible')) {

	    $checkboxes.click( function() { return false; } );

            var choice = [];
            $checkboxes.each(function () {
                choice.push( $(this).is(':checked')? 1 : 0 );
            });

            if(JSON.stringify(wanted) == JSON.stringify(choice)){
                $node.prepend($correct);
            }
            else {
                $node.prepend($incorrect);
            }
        }
        else {
            $node.find('.reporting').remove();
	    $checkboxes.unbind( "click" );
        }
    });
}
