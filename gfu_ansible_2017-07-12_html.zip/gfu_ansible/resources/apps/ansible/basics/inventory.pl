#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
use JSON;

my %opts;

GetOptions(\%opts,
	   "list",
	   "host=s");

my @hosts;

open(my $file, "<", "/etc/hosts") || die $!;

while (<$file>) {
    next if /^\s*#/ ; # skip comments
    next if /^\s*$/ ; # skip blank lines
    chomp;
    my ($ip, $host) = split (/\s+/);
    push @hosts, $host if $ip =~ /^192\.168/;
}
close $file;

my $inv = {
    'test-servers' => [ @hosts ]
};

my $json = JSON->new;
print $json->pretty->encode($inv) if $opts{list};
print $json->pretty->encode( {} ) if $opts{host};
